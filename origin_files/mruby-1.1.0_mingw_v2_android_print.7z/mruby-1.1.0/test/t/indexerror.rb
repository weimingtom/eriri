##
# IndexError ISO Test

assert('IndexError', '15.2.33') do
  assert_equal Class, IndexError.class
end
