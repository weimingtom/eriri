/**
 * Part of SDL test suite.
 *
 * Written by Edgar Simo "bobbens"
 *
 * Released under Public Domain.
 */


#ifndef _TEST_AUDIO
#  define _TEST_AUDIO


int test_audio (void);


#endif /* _TEST_AUDIO */

